package com.house.web.adminmanage;

import lombok.Data;

@Data
public class ManageMemDTO {
	private String seq;
	private String name;
	private String id;
	private String ssn;
	private String email;
	private String address;
	private String tel;
	private String active;
	
}