package com.house.web.brokermain;

import lombok.Data;

@Data
public class BrokerMainDTO {
	private String seq;
	private String content;
	private String title;
	private String regdate;
	private String id;
	
	private String jeonse;
	private String monthly;
	private String sales;
}
