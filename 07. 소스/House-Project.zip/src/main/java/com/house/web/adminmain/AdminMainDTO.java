package com.house.web.adminmain;

import lombok.Data;

@Data
public class AdminMainDTO {
	private String seq;
	private String id;
	private String realEstateSeq;
	private String content;
	private String state;

	}




