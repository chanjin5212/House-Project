package com.house.web.brokermypage;

public class BrokerInfoDTO {

}
