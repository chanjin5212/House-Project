package com.house.web.adminreport;

import lombok.Data;

@Data
public class ReportDTO {
	private String seq;
	private String buildingTypeSeq;
	private String realEstateAddr;
	private String id;
	private String state;
	private String content;

	}



