package com.house.domain.admin;

import lombok.Data;

@Data
public class AdminDTO {

	private String id;
	private String pw;
	
	
}
