package com.house.domain.sign;

import lombok.Data;

@Data
public class SignDTO {
	
	private String id;
	private String name;
	private String email;
	private String ssn;
	private String tel;
	private String address;
	private String pw;
	private String active;
	private String lv;
	private String x;
	private String y;
	

}

