package com.house.domain.emailauth;

public class GmailVO {
	private static String id = "projectTest1067@gmail.com";
	private static String pw = "gwipwwbkdkvmtexm";
	
	public static String getId() {
		return id;
	}
	public static String getPw() {
		return pw;
	}

}
